rootProject.name = "WhipApp"
include(":app")
